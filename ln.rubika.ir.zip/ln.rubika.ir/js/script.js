//swiper
		var swiper = new Swiper('.swiper-container', {
			loop: true,
			autoplay:
			{
				delay: 2500,
				disableOnInteraction: false,
			},
        });
//Toggle menu
		//var theToggle = document.getElementById('toggle');

		//// based on Todd Motto functions
		//// https://toddmotto.com/labs/reusable-js/

		//// hasClass
		//function hasClass(elem, className) {
		//return new RegExp(' ' + className + ' ').test(' ' + elem.className + ' ');
		//}
		//// addClass
		//function addClass(elem, className) {
		//if (!hasClass(elem, className)) {
		//  elem.className += ' ' + className;
		//}
		//}
		//// removeClass
		//function removeClass(elem, className) {
		//var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, ' ') + ' ';
		//if (hasClass(elem, className)) {
		//  while (newClass.indexOf(' ' + className + ' ') >= 0 ) {
		//	newClass = newClass.replace(' ' + className + ' ', ' ');
		//  }
		//  elem.className = newClass.replace(/^\s+|\s+$/g, '');
		//}
		//}
		//// toggleClass
		//function toggleClass(elem, className) {
		//var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, " " ) + ' ';
		//if (hasClass(elem, className)) {
		//  while (newClass.indexOf(" " + className + " ") >= 0 ) {
		//	newClass = newClass.replace( " " + className + " " , " " );
		//  }
		//  elem.className = newClass.replace(/^\s+|\s+$/g, '');
		//} else {
		//  elem.className += ' ' + className;
		//}
		//}

		//theToggle.onclick = function() {
		// toggleClass(this, 'on');
		// return false;
		//}
//view port
		jQuery(document).ready(function () {
		  jQuery('.feature-row').addClass("viewport-hidden").viewportChecker({
			  classToAdd: 'viewport-visible animated fadeInUp', // Class to add to the elements when they are visible
			  offset: 100
		  });
		});

//plax
//$(document).ready(function () {

//		  var enabled = false;
		
//		  $('#PlaxDivOne').hover(function(){
			  
//			  $('.plax-sphere-1').css("transform","none");
//			  $('.plax-sphere-2').css("transform","none");
//			  if(enabled) $.plax.disable({"restorepositions": true,"clearLayers" :true})
			 
//			  $('.plax-sphere-1').plaxify({ "xRange": 40, "yRange": 40 })
//			  $('.plax-sphere-2').plaxify({ "xRange": 60, "yRange": 80 })
//			  $.plax.enable({ "activityTarget": $('#PlaxDivOne')})
//			  enabled = true;
			  
//		  },function(){
//			  $('.plax-sphere-1').css("transform","none !important");
//			  $('.plax-sphere-2').css("transform","none !important");
//		  });
	
	
//		  $('#PlaxDivTwo').hover(function(){
			  
//			  $('.plax-sphere-3').css("transform","none");
//			  if(enabled)  $.plax.disable({"restorepositions": true,"clearLayers" :true});

//			  $('.plax-sphere-3').plaxify({ "xRange": 40, "yRange": 40, "invert": true })
//			  $.plax.enable({ "activityTarget": $('#PlaxDivTwo')})
//			  enabled = true;
			  
//		  },function(){
//			  $('.plax-sphere-3').css("transform","none !important");
//		  });

  
//		  $('#PlaxDivThree').hover(function(){
			  
//			  $('.plax-sphere-4').css("transform","none");
//			  $('.plax-sphere-5').css("transform","none");
//			  if(enabled) $.plax.disable({"restorepositions": true,"clearLayers" :true})
			 
//			  $('.plax-sphere-4').plaxify({ "xRange": 40, "yRange": 40 })
//			  $('.plax-sphere-5').plaxify({ "xRange": 60, "yRange": 80 })
//			  $.plax.enable({ "activityTarget": $('#PlaxDivthree')})
//			  enabled = true;
			  
//		  },function(){
//			  $('.plax-sphere-4').css("transform","none !important");
//			  $('.plax-sphere-5').css("transform","none !important");
//		  });
		
		
//		});